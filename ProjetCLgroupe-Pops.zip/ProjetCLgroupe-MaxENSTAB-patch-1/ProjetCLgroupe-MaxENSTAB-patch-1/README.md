# ProjetCLgroupe
Projet de conception logicielle - JAVA & AGILE

Maxime et Matthieu : Users
Adrien et Pauline : Servers

Backlog du projet

